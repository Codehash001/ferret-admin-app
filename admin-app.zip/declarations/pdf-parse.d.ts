declare module 'pdf-parse/lib/pdf-parse.js' {
  import pdf from 'pdf-parse';

  export default pdf;
}
