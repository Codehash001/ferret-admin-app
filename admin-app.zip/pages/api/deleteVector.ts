// import { PineconeClient } from "@pinecone-database/pinecone";

// const pc = new PineconeClient()
// const index = pc.index("pinecone-index")

// const ns = index.namespace('example-namespace')
// // Delete one record by ID.
// await ns.deleteOne('id-1');
// // Delete more than one record by ID.
// await ns.deleteMany(['id-2', 'id-3']);